<?php include 'db.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Kepegawaian</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h1 class="mt-4 mb-4">Data Kepegawaian</h1>
    <a href="create.php" class="btn btn-primary mb-4">Tambah Data</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>NIP</th>
                <th>Nama Pegawai</th>
                <th>Kota Kelahiran</th>
                <th>Tanggal Lahir</th>
                <th>Mata Pelajaran</th>
                <th>Jenis Kelamin</th>
                <th>Status</th>
                <th>Username</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT * FROM tbl_kepegawaian";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row["id_kepegawaian"]. "</td>
                        <td>" . $row["nip"]. "</td>
                        <td>" . $row["nama_pegawai"]. "</td>
                        <td>" . $row["kota_kelahiran"]. "</td>
                        <td>" . $row["kelahiran"]. "</td>
                        <td>" . $row["matpel"]. "</td>
                        <td>" . $row["jk"]. "</td>
                        <td>" . $row["status"]. "</td>
                        <td>" . $row["username"]. "</td>
                        <td>
                            <a href='update.php?id=" . $row["id_kepegawaian"]. "' class='btn btn-warning btn-sm'>Edit</a>
                            <a href='delete.php?id=" . $row["id_kepegawaian"]. "' class='btn btn-danger btn-sm' onclick='return confirmDelete()'>Delete</a>
                        </td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='10'>0 results</td></tr>";
        }
        $conn->close();
        ?>
        </tbody>
    </table>
</div>
<script src="js/script.js"></script>
</body>
</html>
