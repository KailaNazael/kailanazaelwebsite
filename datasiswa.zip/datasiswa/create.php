<?php include 'db.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Data</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h1 class="mt-4 mb-4">Tambah Data Kepegawaian</h1>
    <form method="post" action="create.php">
        <div class="form-group">
            <label>NIP:</label>
            <input type="text" name="nip" class="form-control" placeholder="Masukkan NIP Anda" required>
        </div>
        <div class="form-group">
            <label>Nama Pegawai:</label>
            <input type="text" name="nama_pegawai" class="form-control" placeholder="Masukkan Nama Anda" required>
        </div>
        <div class="form-group">
            <label>Kota Kelahiran:</label>
            <input type="text" name="kota_kelahiran" class="form-control" placeholder="Masukkan Kota Kelahiran Anda" required>
        </div>
        <div class="form-group">
            <label>Tanggal Lahir:</label>
            <input type="date" name="kelahiran" class="form-control" placeholder="Pilih Tanggal Kelahiran Anda" required>
        </div>
        <div class="form-group">
            <label>Mata Pelajaran:</label>
            <input type="text" name="matpel" class="form-control" placeholder="Masukkan Mata Pelajaran" required>
        </div>
        <div class="form-group">
            <label>Jenis Kelamin:</label>
            <div class="form-check">
                <input type="radio" name="jk" value="L" id="jkL" class="form-check-input" required>
                <label for="jkL" class="form-check-label">Laki-laki</label>
            </div>
            <div class="form-check">
                <input type="radio" name="jk" value="P" id="jkP" class="form-check-input" required>
                <label for="jkP" class="form-check-label">Perempuan</label>
            </div>
        </div>
        <div class="form-group">
            <label>Status:</label>
            <select name="status" class="form-control" required>
                <option value="">Pilih Status</option>
                <option value="Aktif">Aktif</option>
                <option value="Nonaktif">Nonaktif</option>
            </select>
        </div>
        <div class="form-group">
            <label>Username:</label>
            <input type="email" name="username" class="form-control" placeholder="Nama@gmail.com" required>
        </div>
        <input type="submit" name="submit" class="btn btn-primary" value="Tambah">
    </form>
</div>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nip = $_POST["nip"];
    $nama_pegawai = $_POST["nama_pegawai"];
    $kota_kelahiran = $_POST["kota_kelahiran"];
    $kelahiran = $_POST["kelahiran"];
    $matpel = $_POST["matpel"];
    $jk = $_POST["jk"];
    $status = $_POST["status"];
    $username = $_POST["username"];

    $sql = "INSERT INTO tbl_kepegawaian (nip, nama_pegawai, kota_kelahiran, kelahiran, matpel, jk, status, username)
            VALUES ('$nip', '$nama_pegawai', '$kota_kelahiran', '$kelahiran', '$matpel', '$jk', '$status', '$username')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
        header('Location: index.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
<script src="js/script.js"></script>
</body>
</html>
